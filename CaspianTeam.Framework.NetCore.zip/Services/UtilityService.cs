﻿namespace CaspianTeam.Framework.NetCore.Services
{
    public interface IUtilityService
    {

    }

    public class UtilityService : IUtilityService
    {
         
    }
}
