﻿namespace CaspianTeam.Framework.NetCore.Enums.Http
{
    public enum HttpIdType
    {
        ViewContainer
    }
}
 