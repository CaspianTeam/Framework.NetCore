﻿namespace CaspianTeam.Framework.NetCore.Enums.Helpers.TagHelpers.Button
{
    public enum BootstrapButtonSizeType
    {
        Small, Default, Large
    }
}
