﻿namespace CaspianTeam.Framework.NetCore.Enums.Helpers.TagHelpers.Button
{
    public enum ButtonIconDirectionType
    {
        Right, Left
    }
}
