﻿namespace CaspianTeam.Framework.NetCore.Enums.Helpers.TagHelpers.Button
{
    public enum BootstrapButtonType
    {
        Primary = 1, Secondary, Success, Info, Warning, Danger, Dark, Light
    }
}
