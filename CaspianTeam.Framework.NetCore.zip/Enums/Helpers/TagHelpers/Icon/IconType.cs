﻿// ReSharper disable InconsistentNaming
namespace CaspianTeam.Framework.NetCore.Enums.Helpers.TagHelpers.Icon
{
    public enum IconType
    {
        brands = 1,
        solid = 2,
        regular = 3,
        light = 4
    }
}