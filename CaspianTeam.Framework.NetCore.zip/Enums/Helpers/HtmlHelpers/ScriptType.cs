﻿namespace CaspianTeam.Framework.NetCore.Enums.Helpers.HtmlHelpers
{
    public enum ScriptType
    {
        Code,
        Link
    }
}