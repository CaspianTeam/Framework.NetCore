﻿namespace CaspianTeam.Framework.NetCore.Enums.Helpers.HtmlHelpers
{
    public enum MetaTagType
    {
        Description,
        Keywords
    }
}