﻿namespace CaspianTeam.Framework.NetCore.Enums.Frameworks.BaseController.Magics.KendoWindowHandler
{
    public enum KendoWindowActionType
    {
        Open,
        Close
    }
}