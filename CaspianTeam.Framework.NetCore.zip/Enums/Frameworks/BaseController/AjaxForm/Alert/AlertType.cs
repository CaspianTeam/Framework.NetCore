﻿namespace CaspianTeam.Framework.NetCore.Enums.Frameworks.BaseController.AjaxForm.Alert
{
    public enum AlertType
    {
        Overhang,
        Dialog,
        Notify
    }
}