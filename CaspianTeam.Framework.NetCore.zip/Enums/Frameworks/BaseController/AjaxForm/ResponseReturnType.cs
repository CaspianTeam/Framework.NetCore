﻿namespace CaspianTeam.Framework.NetCore.Enums.Frameworks.BaseController.AjaxForm
{
    public enum ResponseReturnType
    {
        ModelState,
        Alert,
        Magics,
        Redirect,
        ViewModel,
        JavaScriptExecuteFunction
    }
}