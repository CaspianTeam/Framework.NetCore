﻿namespace CaspianTeam.Framework.NetCore.Constants
{
    public static class HttpConstant
    {
         public const string SitemapEmptySpaceId = "siteMapEmptySpace";
    }
}
