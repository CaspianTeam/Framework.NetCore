﻿namespace CaspianTeam.Framework.NetCore.Models.Frameworks.BaseController.Magics.KendoWindowHandler
{
    public class KendoWindowOptionModel
    {
        public string Width { get; set; } = "80%";
        public string Height { get; set; }
    }
}
