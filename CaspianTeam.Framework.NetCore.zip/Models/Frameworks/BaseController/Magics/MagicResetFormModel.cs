﻿namespace CaspianTeam.Framework.NetCore.Models.Frameworks.BaseController.Magics
{
    public class MagicResetFormModel
    {
        public string FormId { get; set; }
    }

}
